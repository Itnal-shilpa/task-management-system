import { Test, TestingModule } from '@nestjs/testing';
import { INestApplication, ValidationPipe } from '@nestjs/common';
import * as request from 'supertest';
import { AppModule } from '../src/app.module';

describe('App (e2e)', () => {
  let app: INestApplication;
  let token: string;
  let taskId: string;

  beforeAll(async () => {
    const moduleFixture: TestingModule = await Test.createTestingModule({
      imports: [AppModule],
    }).compile();

    app = moduleFixture.createNestApplication();
    app.useGlobalPipes(new ValidationPipe({ whitelist: true, transform: true }));
    app.setGlobalPrefix('api');
    await app.init();
  });

  afterAll(async () => {
    await app.close();
  });

  it('POST /api/auth/guest -> should create a guest session', async () => {
    const res = await request(app.getHttpServer()).post('/api/auth/guest').send({});
    expect(res.status).toBe(200);
    expect(res.body.accessToken).toBeDefined();
    token = res.body.accessToken;
  });

  it('POST /api/tasks -> should create a task', async () => {
    const res = await request(app.getHttpServer())
      .post('/api/tasks')
      .set('Authorization', `Bearer ${token}`)
      .send({ title: 'Test task', status: 'todo', priority: 'high' });
    expect(res.status).toBe(201);
    expect(res.body.title).toBe('Test task');
    taskId = res.body._id;
  });

  it('GET /api/tasks -> should return paginated tasks', async () => {
    const res = await request(app.getHttpServer())
      .get('/api/tasks?page=1&limit=10')
      .set('Authorization', `Bearer ${token}`);
    expect(res.status).toBe(200);
    expect(res.body.data).toBeInstanceOf(Array);
    expect(res.body.total).toBeGreaterThanOrEqual(1);
  });

  it('PATCH /api/tasks/:id -> should update a task', async () => {
    const res = await request(app.getHttpServer())
      .patch(`/api/tasks/${taskId}`)
      .set('Authorization', `Bearer ${token}`)
      .send({ status: 'done' });
    expect(res.status).toBe(200);
    expect(res.body.status).toBe('done');
  });

  it('DELETE /api/tasks/:id -> should delete a task', async () => {
    const res = await request(app.getHttpServer())
      .delete(`/api/tasks/${taskId}`)
      .set('Authorization', `Bearer ${token}`);
    expect(res.status).toBe(200);
  });

  it('GET /api/tasks without token -> should be unauthorized', async () => {
    const res = await request(app.getHttpServer()).get('/api/tasks');
    expect(res.status).toBe(401);
  });
});
