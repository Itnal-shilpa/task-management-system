import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { Task, TaskDocument } from './schemas/task.schema';
import { CreateTaskDto } from './dto/create-task.dto';
import { UpdateTaskDto } from './dto/update-task.dto';
import { QueryTaskDto } from './dto/query-task.dto';

@Injectable()
export class TasksService {
  constructor(
    @InjectModel(Task.name) private taskModel: Model<TaskDocument>,
  ) {}

  async create(dto: CreateTaskDto, ownerId: string) {
    const task = new this.taskModel({ ...dto, owner: ownerId });
    return task.save();
  }

  async findAll(query: QueryTaskDto, ownerId: string) {
    const { page = 1, limit = 10, status, priority, search } = query;

    const filter: Record<string, any> = { owner: ownerId };
    if (status) filter.status = status;
    if (priority) filter.priority = priority;
    if (search) filter.title = { $regex: search, $options: 'i' };

    const skip = (page - 1) * limit;

    const [data, total] = await Promise.all([
      this.taskModel.find(filter).skip(skip).limit(limit).sort({ createdAt: -1 }),
      this.taskModel.countDocuments(filter),
    ]);

    return {
      data,
      total,
      page,
      totalPages: Math.ceil(total / limit),
    };
  }

  async findOne(id: string, ownerId: string) {
    const task = await this.taskModel.findOne({ _id: id, owner: ownerId });
    if (!task) throw new NotFoundException('Task not found');
    return task;
  }

  async update(id: string, dto: UpdateTaskDto, ownerId: string) {
    const task = await this.taskModel.findOneAndUpdate(
      { _id: id, owner: ownerId },
      dto,
      { new: true },
    );
    if (!task) throw new NotFoundException('Task not found');
    return task;
  }

  async remove(id: string, ownerId: string) {
    const result = await this.taskModel.deleteOne({ _id: id, owner: ownerId });
    if (result.deletedCount === 0) {
      throw new NotFoundException('Task not found');
    }
    return { success: true };
  }
}
